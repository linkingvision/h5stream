============
Eval example
============

Evaluate expressions from command line.
