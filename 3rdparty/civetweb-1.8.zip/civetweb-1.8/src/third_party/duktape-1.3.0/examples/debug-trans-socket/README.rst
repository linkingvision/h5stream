================================================
Debug transport using a simple socket connection
================================================

This example implements an example debug transport which uses a Linux server
socket on the debug target.
